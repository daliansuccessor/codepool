import os
import datetime

# 生成日期列表
def generate_date_list():
    date_list = []
    today = datetime.date.today()
    end_date = datetime.date(2023, 4, 25)
    days = (today - end_date).days
    for i in range(1, days + 1):
        date = today - datetime.timedelta(days=i)
        date_list.append(date.strftime('%Y-%m-%d')) 
    return date_list

# 生成HTML页面
def generate_html(date_list):
    html = '<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv="X-UA-Compatible" charset=utf-8 content="IE=edge, chrome=1">\n<meta name=viewport content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">\n<link rel="stylesheet" type="text/css" href="https://lunfansuo.com/css/style.css">\n<link rel=icon href="https://lunfansuo.com/favicon.ico">\n<title>消息日记</title>\n</head>\n<body>\n<h1>消息日记</h1>\n<ul>\n<li><a href="https://message.lunfansuo.com" target="_blank">即时</a></li>\n'
    for date in date_list:
        html += '<li><a href="https://message.lunfansuo.com/{}.html" target="_blank">{}</a></li>\n'.format(date.replace('-', ''), date)
    html += '</ul>\n</body>\n</html>'
    return html

# 写入HTML文件
def write_html(html):
    file_path = '/home/message/htdocs/message.lunfansuo.com/news.html'
    with open(file_path, 'w') as f:
        f.write(html)

# 生成日期列表、HTML页面并写入HTML文件
date_list = generate_date_list()
html = generate_html(date_list)
write_html(html)