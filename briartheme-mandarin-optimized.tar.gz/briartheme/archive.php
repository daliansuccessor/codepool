<?php
/**
 * The template for displaying archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Briar
 * @since 1.0
 */

get_header(); ?>

	<div class="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<?php
						the_archive_title( '<h1 class="page-title">', '</h1>' );
						the_archive_description( '<h5>', '</h5>' );
					?>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- /.page title -->

	<div class="container">
		<div class="row">
			<div class="<?php briar_main_class(); ?>">
				<div class="post-list" id="content" role="main">
 
                  
				<?php if ( have_posts() ) : ?>
                    
                  <form role="search" method="get" class="search-form" action="<?php echo esc_attr( home_url( '/' ) ); ?>">
					<input name="s" class="search-form__field form-control" type="search" placeholder="<?php echo esc_attr_x( '搜索信用卡 &hellip;', 'placeholder', 'briar' ) ?>" value="<?php echo get_search_query() ?>" />
					<input class="search-form__button fa" type="submit" value="&#xf002" />
				  </form>
                    <p> </p>
                    
                    
					<?php while ( have_posts() ) : the_post(); ?>
						
							<?php
								get_template_part( 'content', get_post_format() );
							?>
						
					<?php endwhile; ?>
					<?php briar_pagination(); ?>
				<?php else : ?>
					
						<?php get_template_part( 'content', 'none' ); ?>
					
				<?php endif; ?>

				</div>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</div>

<?php get_footer();
