import os
import datetime

# 获取当前时间
now = datetime.datetime.now()

# 计算前一天日期
yesterday = now - datetime.timedelta(days=1)

# 构造新文件名
new_name = '/home/message/htdocs/message.lunfansuo.com/{:%Y%m%d}.html'.format(yesterday)

# 原文件名
old_name = '/home/message/htdocs/message.lunfansuo.com/index.html'

# 文件重命名
os.rename(old_name, new_name)