import requests
from bs4 import BeautifulSoup
import os
import datetime

# 定义socks5代理
proxies = {
    'http': 'socks5://127.0.0.1:10080',
    'https': 'socks5://127.0.0.1:10080'
}

# 请求数据
url1 = 'https://t.me/s/Financial_Express'
url2 = 'https://t.me/s/caijinghub'
response1 = requests.get(url1, proxies=proxies)
response2 = requests.get(url2, proxies=proxies)
html_content = response1.text + response2.text

# 解析数据
soup = BeautifulSoup(html_content, 'html.parser')
messages = soup.find_all('div', {'class': 'tgme_widget_message'})

# 文件路径
file_path = '/home/message/htdocs/message.lunfansuo.com/index.html'

# 读取已有内容，如果文件不存在则创建一个新文件
if os.path.exists(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        existing_content = f.read().strip()
else:
    existing_content = '<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv="X-UA-Compatible" charset=utf-8 content="IE=edge, chrome=1">\n<meta name=viewport content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">\n<link rel="stylesheet" type="text/css" href="https://lunfansuo.com/css/style.css">\n<link rel=icon href="https://lunfansuo.com/favicon.ico">\n<title>财经消息</title>\n</head>\n<body>\n<h1>财经消息</h1>\n<p><a href="https://message.lunfansuo.com/news.html" target="_blank">[日期索引]</a></p>\n'

# 删除旧内容中的标签
existing_content = existing_content.replace('<!DOCTYPE html>', '').replace('<html>', '').replace('<head>', '').replace('<meta http-equiv=Content-Type content="text/html; charset=utf-8">', '').replace('<title>财经消息</title>', '').replace('<meta http-equiv="X-UA-Compatible" charset=utf-8 content="IE=edge, chrome=1">', '').replace('<meta name=viewport content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">', '').replace('</head>', '').replace('<link rel="stylesheet" type="text/css" href="https://lunfansuo.com/css/style.css">', '').replace('<link rel=icon href="https://lunfansuo.com/favicon.ico">', '').replace('<body>', '').replace('</body>', '').replace('</html>', '').replace('<meta charset=UTF-8>', '').replace('<h1>财经消息</h1>', '').replace('\n\n', '').replace('<p><a href="https://message.lunfansuo.com/news.html" target="_blank">[日期索引]</a></p>', '')

# 写入新内容
new_content = ''
for message in reversed(messages):
    # 提取时间
    time_tag = message.find('time', {'class': 'time'})
    time_str = datetime.datetime.strptime(time_tag['datetime'][:-9], '%Y-%m-%dT%H:%M')
    time_str += datetime.timedelta(hours=8)
    time_str = '[' + time_str.strftime('%Y-%m-%d %H:%M') + '] '
    
    # 提取内容
    content_tag = message.find('div', {'class': 'tgme_widget_message_text'})
    content_str = content_tag.get_text(strip=True)
    
    # 删除所有的「原文链接」文字
    content_str = content_str.replace('。原文链接', '。')
    content_str = content_str.replace('）原文链接', '）')
    content_str = content_str.replace('”原文链接', '”')
    
    # 检查是否已存在相同内容
    if time_str + content_str not in existing_content:
        new_content += f'<p>{time_str}{content_str}</p>\n'

# 写入新内容到文件
with open(file_path, 'w', encoding='utf-8') as f:
    f.write('<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv="X-UA-Compatible" charset=utf-8 content="IE=edge, chrome=1">\n<meta name=viewport content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">\n<link rel="stylesheet" type="text/css" href="https://lunfansuo.com/css/style.css">\n<link rel=icon href="https://lunfansuo.com/favicon.ico">\n<title>财经消息</title>\n</head>\n<body>\n<h1>财经消息</h1>\n<p><a href="https://message.lunfansuo.com/news.html" target="_blank">[日期索引]</a></p>\n')
    f.write(new_content + existing_content)

# 补充页面尾部
with open(file_path, 'a', encoding='utf-8') as f:
    f.write('\n</body>\n</html>')