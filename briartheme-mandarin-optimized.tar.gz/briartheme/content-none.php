<?php
/**
 * The template part for displaying a message that posts cannot be found.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Briar
 * @since 1.0
 */

?>

<div class="row">
	<div <?php post_class( array( 'post-item', 'clearfix' ) ); ?>>
		<div class="<?php if ( has_post_thumbnail() ) : ?>col-sm-8<?php else : ?>col-sm-12<?php endif; ?>">
			<h3><?php esc_html_e( '未寻得相关页面', 'briar' ); ?></h3>

			<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

			<p><?php printf( wp_kses( __( '想要发布一篇？<a href="%1$s">点击这里</a>。', 'briar' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

			<?php elseif ( is_search() ) : ?>

			<p><?php esc_html_e( '未搜索到相关关键词，建议您换一个词试试。', 'briar' ); ?></p>
			<?php get_search_form(); ?>

			<?php else : ?>

			<p><?php esc_html_e( '未找到这个页面，您可以试一下搜索关键词。', 'briar' ); ?></p>
			<?php get_search_form(); ?>

			<?php endif; ?>
		</div><!-- /.col -->
	</div><!-- /.post-item -->
</div><!-- /.row -->
